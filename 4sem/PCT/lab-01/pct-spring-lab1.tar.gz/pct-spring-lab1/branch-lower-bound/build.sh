#!/bin/sh

gcc -g -o lb ./lb.c

