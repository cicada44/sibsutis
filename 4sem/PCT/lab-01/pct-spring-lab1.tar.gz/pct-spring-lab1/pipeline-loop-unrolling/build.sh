#!/bin/sh

gcc -g -fopt-info -o prog ./prog.c

