#include "tPoint.hpp"

int main(void) {
    tPoint f;
    f.start((char)0);
    return 0;
}